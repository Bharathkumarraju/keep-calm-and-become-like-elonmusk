def search4letters(phrase:str, letters:str="aeiou") -> set:
    return print(set(letters).intersection(set(phrase)))

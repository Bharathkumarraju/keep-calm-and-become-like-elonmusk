from setuptools import setup

setup(
    name='wordsearch',
    version='1.0',
    description='hanumans search tools',
    author='bhajrangbhali',
    author_email='hanuman@god.com',
    url='bhajrang.com',
    py_modules=['wordsearch']
)